# Json for Visual Studio Code

## Version 1.0.4 January 20, 2020

### New Features

- /

### Bug Fixes

- Fix sidebar icons.

---

## Version 1.0.1 February 28, 2019

### New Features

- Add menu node one-click folding function.

### Bug Fixes

- Solve the problem that vscode-json can't display.

---

## Version 1.0.0 February 28, 2019

### New Features

- Add json view

### Bug Fixes

- null



